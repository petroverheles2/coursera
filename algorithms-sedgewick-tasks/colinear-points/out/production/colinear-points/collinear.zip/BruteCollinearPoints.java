import edu.princeton.cs.algs4.Merge;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by petroverheles on 2/25/18.
 */
public class BruteCollinearPoints {
    private List<LineSegment> segments = new ArrayList<>();

    // finds all line segments containing 4 points
    public BruteCollinearPoints(Point[] points) {
        if (points == null) {
            throw new IllegalArgumentException();
        }

        for (int i = 0; i < points.length - 1; i++) {
            for (int j = i + 1; j < points.length; j++) {
                if (points[i].compareTo(points[j]) == 0) {
                    throw new IllegalArgumentException();
                }
            }
        }

        if (points.length < 4) {
            return;
        }

        Merge.sort(points);

        for (int i = 0; i < points.length - 3; i++) {
            for (int k = i + 1; k < points.length - 2; k++) {
                for (int m = k + 1; m < points.length - 1; m++) {
                    for (int n = m + 1; n < points.length; n++) {
                        Point p1 = points[i];
                        Point p2 = points[k];
                        Point p3 = points[m];
                        Point p4 = points[n];

                        if (p1.slopeOrder().compare(p2, p3) == 0 && p2.slopeOrder().compare(p3, p4) == 0) {
                            LineSegment segment = new LineSegment(p1, p4);
                            segments.add(segment);
                        }
                    }
                }
            }
        }
    }

    // the number of line segments
    public int numberOfSegments() {
        return segments.size();
    }

    // the line segments
    public LineSegment[] segments() {
        return segments.toArray(new LineSegment[segments.size()]);
    }

    public static void main(String[] args) {
        int n = StdIn.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            points[i] = new Point(StdIn.readInt(), StdIn.readInt());
        }

        BruteCollinearPoints bruteCollinearPoints = new BruteCollinearPoints(points);

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        StdDraw.enableDoubleBuffering();
//        for (Point point : points) {
//            StdDraw.filledCircle(point.getX(), point.getY(), 150.0);
//        }
        for (LineSegment lineSegment : bruteCollinearPoints.segments()) {
            StdOut.println(lineSegment);
            lineSegment.draw();
        }
        StdDraw.show();

    }
}
