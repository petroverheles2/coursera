import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FastCollinearPoints {
    private List<LineSegment> segments = new ArrayList<>();

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {
        if (points == null) {
            throw new IllegalArgumentException();
        }

        if (points.length < 4) {
            return;
        }

        Point[] aux = new Point[4];
        for (int i = 0; i < points.length; i++) {
            Arrays.sort(points, points[i].slopeOrder());

            Point origin = points[0];

            for (int k = 1; k < points.length - 2; k++) {
                if (origin.slopeOrder().compare(points[k], points[k + 1]) == 0
                        && origin.slopeOrder().compare(points[k + 1], points[k + 2]) == 0) {
                    aux[0] = origin;
                    aux[1] = points[k];
                    aux[2] = points[k + 1];
                    aux[3] = points[k + 2];
                    Arrays.sort(aux);
                    LineSegment segment = new LineSegment(aux[0], aux[3]);
                    segments.add(segment);
                }
            }
        }
    }

    // the number of line segments
    public int numberOfSegments() {
        return segments.size();
    }

    // the line segments
    public LineSegment[] segments() {
        return segments.toArray(new LineSegment[segments.size()]);
    }

    public static void main(String[] args) {
        int n = StdIn.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            points[i] = new Point(StdIn.readInt(), StdIn.readInt());
        }

        FastCollinearPoints fastCollinearPoints = new FastCollinearPoints(points);

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        StdDraw.enableDoubleBuffering();
//        for (Point point : points) {
//            StdDraw.filledCircle(point.getX(), point.getY(), 150.0);
//        }
        for (LineSegment lineSegment : fastCollinearPoints.segments()) {
            StdOut.println(lineSegment);
            lineSegment.draw();
        }
        StdDraw.show();
    }
}
